package p5;

import java.util.Random;

public class OrdinaryPlayer extends Player{
	private Dice dice;
	private Random rand = new Random();
	
	public OrdinaryPlayer(String name){
		super(name);
		this.dice = new SimpleDice();
	}
	
	public OrdinaryPlayer(String name, Dice dice){
		super(name);
		this.dice = dice;
	}
	
	public void setDice(Dice dice){
		this.dice = dice;
		
	}
	public Dice getDice(){
		return dice;
	}

	public int getDiceSides()
	{
		return this.dice.getSides();
	}
	
	public int throwDice() {
		
		int res = rand.nextInt(dice.getSides())+1;
		
		
		return res;
	}
	
}
